#!/bin/bash

clear
echo -e "================================================="
echo -e "#     Premium Auto Script By🧑‍💻🥷🎮☁️🎰🌊🛫☁️☁️☁️☁️☁️☁️☁️🏦💵♾️⛽ Cyberpunk☁️      #"
echo -e "================================================="
echo -e "# For Debian 10 64 bit                          #"
echo -e "# For Ubuntu 18.04 & Ubuntu 20.04 64 bit        #"
echo -e "# For VPS with KVM and VMWare virtualization    #"
echo -e "# Build Up By🧑‍💻🥷🎮☁️🎰🌊🛫☁️☁️☁️☁️☁️☁️☁️🏦💵♾️⛽ Cyberpunk☁️                     #"
echo -e "================================================="
echo -e "# Thanks To TOpPLUG☁️☁️☁️⛽♾️💵🏦🛫🌊🎰🎮🥷🧑‍💻🗽🏴‍☠️                                  #"
echo -e "================================================="
echo -e "# Allah SWT                                     #"
echo -e "# My Family                                     #"
echo -e "# 🧑‍💻🥷🎮☁️🎰🌊🛫☁️☁️☁️☁️☁️☁️☁️🏦💵♾️⛽ Cyberpunk☁️                                        #"
echo -e "# Horasss                                       #"
echo -e "================================================="
